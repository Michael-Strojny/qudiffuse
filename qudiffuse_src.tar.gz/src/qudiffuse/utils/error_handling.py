#!/usr/bin/env python3
"""
Centralized Error Handling for QuDiffuse

This module provides standardized error handling patterns and custom exceptions
to ensure consistent error reporting across the codebase.
"""

from typing import Optional, Any, Union, List
import logging

import torch

logger = logging.getLogger(__name__)

class QuDiffuseError(Exception):
    """Base exception class for QuDiffuse-specific errors."""
    
    def __init__(self, message: str, component: str = "unknown", details: Optional[dict] = None):
        self.component = component
        self.details = details or {}
        super().__init__(f"[{component.upper()}] {message}")

class ConfigurationError(QuDiffuseError):
    """Raised when there are configuration-related errors."""
    def __init__(self, message: str = "Configuration validation error", component: str = "config"):
        super().__init__(message, component)

class TopologyError(QuDiffuseError):
    """Raised when there are topology-related errors."""
    def __init__(self, message: str = "Binary latent topology error", component: str = "topology"):
        super().__init__(message, component)

class BinaryLatentError(QuDiffuseError):
    """Raised when there are binary latent space errors."""
    def __init__(self, message: str = "Binary latent operation error", component: str = "binary_latent"):
        super().__init__(message, component)

class DBNError(QuDiffuseError):
    """Raised when there are DBN-related errors."""
    def __init__(self, message: str = "Deep Belief Network error", component: str = "dbn"):
        super().__init__(message, component)

class AutoencoderError(QuDiffuseError):
    """Raised when there are autoencoder-related errors."""
    def __init__(self, message: str = "Autoencoder operation error", component: str = "autoencoder"):
        super().__init__(message, component)

class TrainingError(QuDiffuseError):
    """Raised when there are training-related errors."""
    def __init__(self, message: str = "Training process error", component: str = "training"):
        super().__init__(message, component)

class QUBOError(QuDiffuseError):
    """Raised when there are QUBO-related errors."""
    def __init__(self, message: str = "QUBO formulation or solving error", component: str = "qubo"):
        super().__init__(message, component)

def validate_tensor_properties(tensor: torch.Tensor, name: str = "tensor", 
                              expected_dtype: Optional[torch.dtype] = None,
                              expected_device: Optional[torch.device] = None,
                              expected_shape: Optional[tuple] = None,
                              min_dims: Optional[int] = None,
                              max_dims: Optional[int] = None,
                              allow_empty: bool = True) -> None:
    """
    Comprehensive tensor validation with standardized error messages.
    
    Args:
        tensor: Tensor to validate
        name: Name for error messages
        expected_dtype: Expected data type
        expected_device: Expected device
        expected_shape: Expected shape (use -1 for any dimension)
        min_dims: Minimum number of dimensions
        max_dims: Maximum number of dimensions
        allow_empty: Whether to allow empty tensors
    """
    if not isinstance(tensor, torch.Tensor):
        raise BinaryLatentError(f"{name} must be a torch.Tensor, got {type(tensor)}", "tensor_validation")
    
    if not allow_empty and tensor.numel() == 0:
        raise BinaryLatentError(f"{name} cannot be empty", "tensor_validation")
    
    if expected_dtype is not None and tensor.dtype != expected_dtype:
        raise BinaryLatentError(
            f"{name} expected dtype {expected_dtype}, got {tensor.dtype}", 
            "tensor_validation"
        )
    
    if expected_device is not None and tensor.device != expected_device:
        raise BinaryLatentError(
            f"{name} expected device {expected_device}, got {tensor.device}", 
            "tensor_validation"
        )
    
    if min_dims is not None and tensor.dim() < min_dims:
        raise BinaryLatentError(
            f"{name} expected at least {min_dims} dimensions, got {tensor.dim()}", 
            "tensor_validation"
        )
    
    if max_dims is not None and tensor.dim() > max_dims:
        raise BinaryLatentError(
            f"{name} expected at most {max_dims} dimensions, got {tensor.dim()}", 
            "tensor_validation"
        )
    
    if expected_shape is not None:
        if tensor.dim() != len(expected_shape):
            raise BinaryLatentError(
                f"{name} expected {len(expected_shape)} dimensions, got {tensor.dim()}", 
                "tensor_validation"
            )
        
        for i, (actual, expected) in enumerate(zip(tensor.shape, expected_shape)):
            if expected != -1 and actual != expected:
                raise BinaryLatentError(
                    f"{name} dimension {i} expected {expected}, got {actual}", 
                    "tensor_validation"
                )

def validate_topology_config(config: dict, component: str = "topology") -> None:
    """
    Validate topology configuration with standardized errors.
    
    Args:
        config: Topology configuration dictionary
        component: Component name for error messages
    """
    if not isinstance(config, dict):
        raise TopologyError(f"Configuration must be a dictionary, got {type(config)}", component)
    
    if 'type' not in config:
        raise TopologyError("Configuration missing required 'type' field", component)
    
    topology_type = config['type']
    if topology_type not in ['hierarchical', 'flat', 'mixed']:
        raise TopologyError(
            f"Invalid topology type '{topology_type}'. Must be 'hierarchical', 'flat', or 'mixed'", 
            component
        )
    
    if topology_type == 'flat':
        required_keys = ['channels', 'spatial_size']
        missing_keys = [key for key in required_keys if key not in config]
        if missing_keys:
            raise TopologyError(f"Flat topology missing required keys: {missing_keys}", component)
    
    elif topology_type in ['hierarchical', 'mixed']:
        if 'levels' not in config:
            raise TopologyError(f"{topology_type} topology missing required 'levels' field", component)
        
        levels = config['levels']
        if not isinstance(levels, list) or len(levels) == 0:
            raise TopologyError(f"{topology_type} topology 'levels' must be a non-empty list", component)
        
        for i, level in enumerate(levels):
            if not isinstance(level, dict):
                raise TopologyError(f"Level {i} must be a dictionary", component)
            
            required_level_keys = ['channels', 'spatial_size']
            missing_level_keys = [key for key in required_level_keys if key not in level]
            if missing_level_keys:
                raise TopologyError(f"Level {i} missing required keys: {missing_level_keys}", component)

def validate_dbn_configuration(latent_dims: List[int], hidden_dims: List[int], 
                              component: str = "dbn") -> None:
    """
    Validate DBN configuration parameters.
    
    Args:
        latent_dims: List of latent dimensions
        hidden_dims: List of hidden dimensions
        component: Component name for error messages
    """
    if not isinstance(latent_dims, list) or len(latent_dims) == 0:
        raise DBNError("latent_dims must be a non-empty list", component)
    
    if not isinstance(hidden_dims, list) or len(hidden_dims) == 0:
        raise DBNError("hidden_dims must be a non-empty list", component)
    
    if len(latent_dims) != len(hidden_dims):
        raise DBNError(
            f"latent_dims and hidden_dims must have same length: {len(latent_dims)} vs {len(hidden_dims)}", 
            component
        )
    
    for i, (latent_dim, hidden_dim) in enumerate(zip(latent_dims, hidden_dims)):
        if not isinstance(latent_dim, int) or latent_dim <= 0:
            raise DBNError(f"latent_dims[{i}] must be positive integer, got {latent_dim}", component)
        
        if not isinstance(hidden_dim, int) or hidden_dim <= 0:
            raise DBNError(f"hidden_dims[{i}] must be positive integer, got {hidden_dim}", component)

def validate_training_config(config: dict, component: str = "training") -> None:
    """
    Validate training configuration.
    
    Args:
        config: Training configuration dictionary
        component: Component name for error messages
    """
    required_keys = ['learning_rate', 'batch_size', 'epochs']
    missing_keys = [key for key in required_keys if key not in config]
    if missing_keys:
        raise TrainingError(f"Training config missing required keys: {missing_keys}", component)
    
    # Validate learning rate
    lr = config['learning_rate']
    if not isinstance(lr, (int, float)) or lr <= 0:
        raise TrainingError(f"learning_rate must be positive number, got {lr}", component)
    
    # Validate batch size
    batch_size = config['batch_size']
    if not isinstance(batch_size, int) or batch_size <= 0:
        raise TrainingError(f"batch_size must be positive integer, got {batch_size}", component)
    
    # Validate epochs
    epochs = config['epochs']
    if not isinstance(epochs, int) or epochs <= 0:
        raise TrainingError(f"epochs must be positive integer, got {epochs}", component)

def handle_cuda_error(operation: str, error: Exception, component: str = "cuda") -> None:
    """
    Handle CUDA-related errors with informative messages.
    
    Args:
        operation: Description of operation that failed
        error: Original exception
        component: Component name for error messages
    """
    if "out of memory" in str(error).lower():
        raise TrainingError(
            f"CUDA out of memory during {operation}. Try reducing batch size or model size.", 
            component,
            details={'original_error': str(error), 'operation': operation}
        ) from error
    elif "device" in str(error).lower():
        raise TrainingError(
            f"CUDA device error during {operation}. Check device availability.", 
            component,
            details={'original_error': str(error), 'operation': operation}
        ) from error
    else:
        raise TrainingError(
            f"CUDA error during {operation}: {error}", 
            component,
            details={'original_error': str(error), 'operation': operation}
        ) from error

def safe_operation(operation: callable, *args, operation_name: str = "operation",
                  component: str = "unknown", **kwargs) -> Any:
    """
    Safely execute operation with standardized error handling.
    
    Args:
        operation: Function to execute
        *args: Positional arguments for operation
        operation_name: Name of operation for error messages
        component: Component name for error messages
        **kwargs: Keyword arguments for operation
    
    Returns:
        Result of operation
    """
    try:
        return operation(*args, **kwargs)
    except torch.cuda.OutOfMemoryError as e:
        handle_cuda_error(operation_name, e, component)
    except RuntimeError as e:
        if "cuda" in str(e).lower():
            handle_cuda_error(operation_name, e, component)
        else:
            raise QuDiffuseError(f"Runtime error in {operation_name}: {e}", component) from e
    except Exception as e:
        raise QuDiffuseError(f"Unexpected error in {operation_name}: {e}", component) from e

def log_error_context(error: Exception, context: dict, component: str = "unknown") -> None:
    """
    Log error with context information.
    
    Args:
        error: Exception that occurred
        context: Context information dictionary
        component: Component name
    """
    logger.error(f"[{component.upper()}] Error: {error}")
    logger.error(f"[{component.upper()}] Context: {context}")

def validate_qubo_format(Q: dict, component: str = "qubo") -> None:
    """
    Validate QUBO format.
    
    Args:
        Q: QUBO dictionary
        component: Component name for error messages
    """
    if not isinstance(Q, dict):
        raise QUBOError(f"QUBO must be a dictionary, got {type(Q)}", component)
    
    for key, value in Q.items():
        if not isinstance(key, tuple) or len(key) != 2:
            raise QUBOError(f"QUBO keys must be 2-tuples, got {key}", component)
        
        i, j = key
        if not isinstance(i, int) or not isinstance(j, int):
            raise QUBOError(f"QUBO indices must be integers, got ({type(i)}, {type(j)})", component)
        
        if i > j:
            raise QUBOError(f"QUBO must be upper triangular, got ({i}, {j})", component)
        
        if not isinstance(value, (int, float)):
            raise QUBOError(f"QUBO values must be numeric, got {type(value)}", component)
